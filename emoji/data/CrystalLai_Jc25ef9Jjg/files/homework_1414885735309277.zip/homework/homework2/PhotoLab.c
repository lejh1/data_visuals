/*********************************************************************/
/* PhotoLab.c: assignment 2 for EECS 22 in Fall 2017                 */
/*                                                                   */
/* modifications: (Saeed Karimi Bidhendi)                            */
/* 09/27/17 RD	adjusted for lecture usage                           */
/* Crystal's PHOTOLAB Assignment                                     */
/* Student ID: 57144810                                              */
/*********************************************************************/

/*** header files ***/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*** global definitions ***/

const int WIDTH  = 600;	/* image width */
const int HEIGHT = 400;	/* image height */
const int SLEN   =  80;	/* max. string length */

/*** function declarations ***/

void PrintMenu();

/* read image from a file */
int LoadImage(const char fname[SLEN], unsigned char R[WIDTH][HEIGHT],
              unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT]);

/* save a processed image */
int SaveImage(const char fname[SLEN], unsigned char R[WIDTH][HEIGHT],
              unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT]);

/* reverse image color */
void Negative(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],
              unsigned char B[WIDTH][HEIGHT]);

/* color filter */
void ColorFilter(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],
                 unsigned char B[WIDTH][HEIGHT], int target_r, int target_g,
                 int target_b, int threshold, int replace_r, int replace_g, int replace_b);

/* edge detection */
void Edge(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],
          unsigned char B[WIDTH][HEIGHT]);


/* mirror image vertically */
void VMirror(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],
             unsigned char B[WIDTH][HEIGHT]);

/* change color image to black & white */
void BlackNWhite(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],
                 unsigned char B[WIDTH][HEIGHT]);


/* sharpen the image */
void Shuffle(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],
             unsigned char B[WIDTH][HEIGHT]);


/* add border */
void AddBorder(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],
               unsigned char B[WIDTH][HEIGHT], char color[SLEN], int border_width);

/* flip image vertically */
void VFlip(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],
           unsigned char B[WIDTH][HEIGHT]);

/* Test all functions */
void AutoTest(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],
              unsigned char B[WIDTH][HEIGHT]);

/*** main program ***/

int main(void)
{
    unsigned char R[WIDTH][HEIGHT];
    unsigned char G[WIDTH][HEIGHT];
    unsigned char B[WIDTH][HEIGHT];
	int function = 0;
	char fname[SLEN];

    while(function!=12){
        PrintMenu();
        printf("Please make your choice:");
        scanf("%d", &function);
        switch(function){
          case 1:/* Load Image*/ 
                {
                    printf("Please input the file name to load:");
                    scanf(" %s", fname);
                    LoadImage(fname, R, G, B);
                    break;
                }
          case 2:/*Save Image*/
                {
                    printf("Please input the file name to save:");
                    scanf("%s", fname);
                    SaveImage(fname, R, G, B);
                    break;
                }
          case 3:/*B&W*/
                { 
                    BlackNWhite(R,G,B);
                    break;
                }
          case 4:/*Negative*/
                { 
                    Negative(R, G, B);
                    break;
                }
          case 5:/*Color Filter*/
                {
                    /*initializing values to take in*/
                    int target_r, target_g, target_b, threshold, replace_r, replace_g, replace_b;
                    /*takein values*/
                    printf("Enter Red component for the target color:");
                    scanf(" %d", &target_r);	

                    printf("Enter Green component for the target color:");
                    scanf(" %d", &target_g);

                    printf("Enter Blue component for the target color:");
                    scanf(" %d", &target_b);

                    printf("Enter threshold for the color difference:");
                    scanf(" %d", &threshold);


                    printf("Enter Red component for the replacement color:");
                    scanf(" %d", &replace_r);	

                    printf("Enter Green component for the replacement color:");
                    scanf(" %d", &replace_g);

                    printf("Enter Blue component for the replacement color:");
                    scanf(" %d", &replace_b);

                    ColorFilter(R, G, B, target_r, target_g,target_b, threshold, replace_r, replace_g, replace_b);
              
                    break;
                }
          case 6:/*Edge Detection*/
                {
                    Edge(R,G,B);
                    break;
                }
          case 7:/*Shuffle*/
                {
                    Shuffle(R,G,B);
                    break;
                }
          case 8:/*Vertical Flip*/
                {
                    VFlip(R,G,B);
                    break;
                }
          case 9:/*Mirror*/
                {
                    VMirror(R,G, B);
                    break;
                }
          case 10:/*Border*/
                {
                    char color[SLEN];
                    int border_width=0;
                    
                    printf("Enter Border Width:");
                    scanf("%d", &border_width);
                    printf("Available border colors: black, white, red, green, blue, yellow, cyan, pink, orange\n");
                    printf("Select border color from the options:");
                    scanf(" %s", color);
                    
                    AddBorder(R, G, B, color, border_width); 
                   break;
                }
          case 11:/*Test all Functions*/
                {
                    AutoTest(R,G,B);
                    break;
                }
          case 12:/*Exit*/
                {
                    break;
                }
        }/*End of Switch*/
    }/*end of while*/
	
  return 0;
} /* end of main */


/*** function definitions ***/

/*Print menu */

void PrintMenu(){
	printf("------------------------\nSelect an Operation: \n1: Load a PPM image \n2: Save an image in PPM and JPEG format \n3: Change a color image to Black & White \n4: Make a negative of an image \n5: Color filter an image \n6: Sketch the edge of an image \n7: Shuffle an image \n8: Flip an image vertically\n9: Mirror an image vertically\n10: Add Border to an image \n11: Test all functions \n12: Exit\n\n ");
}

/* read a photo from the specified file into the specified */
/* RGB data structure; returns 0 for success, >0 for error */

int LoadImage(const char fname[SLEN], unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT]) {
        FILE           *File;
        char            Type[SLEN];
        int             Width, Height, MaxValue;
        int             x, y;
        char            ftype[] = ".ppm";
        char            fname_tmp[SLEN];      
        strcpy(fname_tmp, fname);
        strcat(fname_tmp, ftype);


        File = fopen(fname_tmp, "r");
        if (!File) {
                printf("Cannot open file \"%s\" for reading!\n", fname);
                return 1;
                    }
        fscanf(File, "%79s", Type);
        if (Type[0] != 'P' || Type[1] != '6' || Type[2] != 0) {
                printf("\nUnsupported file format!\n");
                return 2;
                                                                }
        fscanf(File, "%d", &Width);
        if (Width != WIDTH) {
                printf("\nUnsupported image width %d!\n", Width);
                return 3;
                             }
        fscanf(File, "%d", &Height);
        if (Height != HEIGHT) {
                 printf("\nUnsupported image height %d!\n", Height);
                 return 4;
                              }
        fscanf(File, "%d", &MaxValue);
        if (MaxValue != 255) {
                 printf("\nUnsupported image maximum value %d!\n", MaxValue);
                 return 5;
                            }
        if ('\n' != fgetc(File)) {
                 printf("\nCarriage return expected!\n");
                 return 6;
                                }
        for (y = 0; y < HEIGHT; y++)
             for (x = 0; x < WIDTH; x++) {
                         R[x][y] = fgetc(File);
                         G[x][y] = fgetc(File);
                         B[x][y] = fgetc(File);
                                         }
        if (ferror(File)) {
             printf("\nFile error while reading from file!\n");
             return 7;
                           }
        printf("%s was read.\n", fname_tmp);
        fclose(File);
        return 0;
}

int SaveImage(const char fname[SLEN], unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT]) {
        FILE    *File;
        int x, y;
        char    SysCmd[SLEN * 5];
        char    ftype[] = ".ppm";
        char    fname_tmp[SLEN];  /*avoid to modify on the original pointer, 11/10/10, X.Han*/
        char    fname_tmp2[SLEN];

        strcpy(fname_tmp, fname);
        strcpy(fname_tmp2, fname);
        strcat(fname_tmp2, ftype);

        File = fopen(fname_tmp2, "w");
        if (!File) {
                printf("Cannot open file \"%s\" for writing!\n", fname);
                return 1;
                   }
        fprintf(File, "P6\n");
        fprintf(File, "%d %d\n", WIDTH, HEIGHT);
        fprintf(File, "255\n");
        for (y = 0; y < HEIGHT; y++)
                 for (x = 0; x < WIDTH; x++) {
                               fputc(R[x][y], File);
                               fputc(G[x][y], File);
                               fputc(B[x][y], File);
                                              }
         if (ferror(File)) {
                  printf("\nFile error while writing to file!\n");
                  return 2;
                            }
         fclose(File);
         printf("%s was saved. \n", fname_tmp2);
   /* * * rename file to image.ppm, convert it to ~/public_html/<fname>.jpg ** and make it world readable  **/
       
	 sprintf(SysCmd, "/users/grad2/doemer/eecs22/bin/pnmtojpeg_hw2.tcsh %s", fname_tmp2);
       
	 if (system(SysCmd) != 0) {
        	printf("\nError while converting to JPG:\nCommand \"%s\" failed!\n", SysCmd);
 	       return 3;
                                  }
        printf("%s.jpg was stored.\n", fname_tmp);
        return 0;
}

void BlackNWhite (unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT]){
	int x, y;
	for(y=0; y<HEIGHT; y++){
		for(x=0; x<WIDTH; x++){
            unsigned char newval = (R[x][y]+G[x][y]+B[x][y])/3;
            R[x][y] = newval;
            G[x][y] = newval;
            B[x][y] = newval;
		}
	}
	printf("'Black & White'operation is done!\n");
}


void Negative (unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT]){
	int x, y;
	for (y=0; y<HEIGHT; y++){
		for(x=0; x<WIDTH; x++){
            R[x][y]=255-R[x][y];
            G[x][y]=255-G[x][y];
            B[x][y]=255-B[x][y];
		}
	}	
	printf("Negative operation is done!\n");
}

/* color filter */
void ColorFilter(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT], int target_r, int target_g, int target_b, int threshold, int replace_r, int replace_g, int replace_b){
    int x, y;
	for (y=0;y<HEIGHT; y++){
		for(x=0; x<WIDTH; x++){
			if((R[x][y]>=target_r-threshold && R[x][y] <= target_r +threshold) && 
               (G[x][y]>=target_g-threshold && G[x][y] <= target_g +threshold) && 
               (B[x][y]>=target_b-threshold && B[x][y] <= target_b +threshold))
            {
                R[x][y]= replace_r;
                G[x][y]= replace_g;
                B[x][y]= replace_b;
			}
		 }
	}
    printf("\"ColorFilter\" Operation done! \n ");
}

/* edge detection */
void Edge(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT]){
    int x,y,i,j;
    int temp_r[WIDTH][HEIGHT],temp_g[WIDTH][HEIGHT], temp_b[WIDTH][HEIGHT];
    for(y=0;y<HEIGHT; y++){
        for(x=0;x<WIDTH; x++){
            temp_r[x][y] =(int)R[x][y]*8;
            temp_g[x][y] =(int)G[x][y]*8;
            temp_b[x][y] =(int)B[x][y]*8;
        }
    }
    for(y=0;y<HEIGHT; y++){
        for(x=0;x<WIDTH; x++){
            for (i=-1; i<=1; i++){
                for(j=-1; j<=1; j++){
                    if(i==0&&j==0)continue;
                    if(x+i<0||y+j<0){
                        temp_r[x][y]=0;
                        temp_g[x][y]=0;
                        temp_b[x][y]=0;
                    }
                    if(x+i>=WIDTH||y+j>=HEIGHT){
                        temp_r[x][y]=0;
                        temp_g[x][y]=0;
                        temp_b[x][y]=0;
                    }
                    temp_r[x][y]-= R[x+i][y+j];
                    temp_g[x][y]-= G[x+i][y+j];
                    temp_b[x][y]-= B[x+i][y+j];
                }        
            }
        }
    }
    for(y=0;y<HEIGHT;y++){
        for(x=0; x<WIDTH;x++){
            if(temp_r[x][y]<0) temp_r[x][y]=0;
            if(temp_g[x][y]<0) temp_g[x][y]=0;
            if(temp_b[x][y]<0) temp_b[x][y]=0;
            if(temp_r[x][y]>255) temp_r[x][y]=255;
            if(temp_g[x][y]>255) temp_g[x][y]=255;
            if(temp_b[x][y]>255) temp_b[x][y]=255;
            
            R[x][y]=(unsigned char) temp_r[x][y];
            G[x][y]=(unsigned char)temp_g[x][y];
            B[x][y]=(unsigned char)temp_b[x][y];
        }
    }
    printf("\"Edge\" Operation done! \n ");
}


/* sharpen the image */
void Shuffle(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT])
{
    int block_w, block_h,o;
    
    block_w = WIDTH/4;
    block_h = HEIGHT/4; 

/*picking two blocks*/
    int i,j, block1_row, block1_column, block2_row, block2_column;
    int swapped[16];
    
    
    for (o = 0; o < 16; o++) swapped[o] = 0;/*initializing as 0*/
    for(o = 0; o < 16; o++){/*keeping track of when to stop*/
/*choosing random block to swap*/
        block1_row = rand() %4;
        block1_column = rand() %4;
        while(swapped[(block1_row * block_w) + block1_column] == 1)
        {
            block1_row = rand() % 4;
            block1_column = rand() % 4;
        }

        block2_row = rand() % 4;
        block2_column = rand() % 4;
        while (swapped[block2_row * block_w + block2_column] == 1 ||
              (block1_row == block2_row && block1_column == block2_column)) 
        {
            block2_row = rand() % 4;
            block2_column = rand() % 4;
        }
/*switching the blocks*/
        for(i = 0; i < block_w; i++){
            for(j = 0; j < block_h; j++){
                int x=0, y=0, a=0, b=0, temp=0;

                x = (block1_column) * block_w + i;
                y = (block1_row) * block_h +j;
                
                a = (block2_column) * block_w + i;
                b = (block2_row) * block_h + j;

                temp = R[x][y];
                R[x][y] = R[a][b];
                R[a][b] = temp;
                
                temp = G[x][y];
                G[x][y] = G[a][b];
                G[a][b] = temp;

                temp = B[x][y];
                B[x][y] = B[a][b];
                B[a][b]=temp;
            }
        }
    }
    printf("\"Shuffle\" Operation done! \n ");
}

/* flip image vertically */
void VFlip(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT]){
    int x, y;	
    
    for (y=0;y<HEIGHT/2; y++){
		for(x=0; x<WIDTH; x++){
            unsigned char i;
            i = R[x][HEIGHT-1-y];
            R[x][HEIGHT-1-y]=R[x][y];
            R[x][y]=i;
            
            i = G[x][HEIGHT-1-y];
            G[x][HEIGHT-1-y]=G[x][y];
            G[x][y]=i;
            
            i = B[x][HEIGHT-1-y];
            B[x][HEIGHT-1-y]=B[x][y];
            B[x][y]=i;
        }
    }  
    printf("\"Vertical Flip\" Operation done! \n");
 }

/* mirror image vertically */
void VMirror(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT],unsigned char B[WIDTH][HEIGHT])
{
    int x, y;

    for(y=0;y<HEIGHT/2;y++){
        for(x=0;x<WIDTH;x++){
            R[x][HEIGHT-1-y]=R[x][y];
            G[x][HEIGHT-1-y]=G[x][y];
            B[x][HEIGHT-1-y]=B[x][y];
        }
     }
    printf("\"Vertical Mirror\" Operation done! \n");
}

/* add border */
void AddBorder(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT], char color[SLEN], int border_width){
            int r=0, g=0, b=0, y=0, x=0;

            if (strcmp(color, "black")==0){
                    r=0;
                    g=0;
                    b=0;
           } else if (strcmp(color, "white")==0){
                    r=255;
                    g=255;
                    b=255;
           } else if (strcmp(color,"red")==0){
                    r=255;
                    g=0;
                    b=0;
           } else if (strcmp(color,"green")==0){
                    r=0;
                    g=255;
                    b=0;
           } else if (strcmp(color,"blue")==0){
                    r=0;
                    g=0;
                    b=255;
           } else if (strcmp(color,"yellow")==0){
                    r=255;
                    g=255;
                    b=0;
            } else if (strcmp(color,"cyan")==0){
                    r=0;
                    g=255;
                    b=255;
            } else if (strcmp(color,"pink")==0){
                    r=255;
                    g=192;
                    b=203;
            } else if (strcmp(color,"orange")==0){
                    r=255;
                    g=165;
                    b=0;
            }else{
                printf("not a valid color \n");
            }
/*filling top and bottom*/
     for(y=0;y<border_width; y++){
        for(x=0;x<WIDTH; x++){
            R[x][y]= r;
            R[x][y+HEIGHT-border_width]=r;
            G[x][y]= g;
            G[x][y+HEIGHT-border_width]=g;
            B[x][y]= b;
            B[x][y+HEIGHT-border_width]=b;
        }
    }
/*ratio aspecting and filling sides*/
    int ratio = 0;
    ratio = (border_width * 9) /16;

    for(y=0;y<HEIGHT;y++){
        for(x=0;x<(ratio);x++){
            R[x][y]= r;
            R[x+WIDTH-(ratio)][y]=r;
            G[x][y]= g;
            G[x+WIDTH-(ratio)][y]=g;
            B[x][y]= b;
            B[x+WIDTH-(ratio)][y]=b;
        }
    }
    printf("\"Border \" Operation done! \n");
}


/* Test all functions */
void AutoTest(unsigned char R[WIDTH][HEIGHT], unsigned char G[WIDTH][HEIGHT], unsigned char B[WIDTH][HEIGHT]){
    
    char fname[] = "HSSOE";
    char sname[SLEN];
    
    LoadImage(fname,R,G,B);
    BlackNWhite(R,G,B);
    strcpy(sname,"bw");
    SaveImage(sname,R,G,B);
    printf("Black and White tested! \n \n");

    LoadImage(fname,R,G,B);
    Negative(R,G,B);
    strcpy(sname,"negative");
    SaveImage(sname,R,G,B);
    printf("Negative tested! \n \n");

    LoadImage(fname,R,G,B);
    ColorFilter(R,G,B, 190,100,150,60,0,0,255);
    strcpy(sname,"colorfilter");
    SaveImage(sname,R,G,B);
    printf("Color Filter tested! \n \n");

    LoadImage(fname,R,G,B);
    Edge(R,G,B);
    strcpy(sname,"edge");
    SaveImage(sname,R,G,B);
    printf("Edge tested! \n \n");

    LoadImage(fname,R,G,B);
    Shuffle(R,G,B);
    strcpy(sname,"shuffle");
    SaveImage(sname,R,G,B);
    printf("Shuffle tested! \n \n");

    LoadImage(fname,R,G,B);
    VFlip(R,G,B);
    strcpy(sname,"vflip");
    SaveImage(sname,R,G,B);
    printf("VFlip tested! \n \n");

    LoadImage(fname,R,G,B);
    VMirror(R,G,B);
    strcpy(sname,"vmirror");
    SaveImage(sname,R,G,B);
    printf("VMirror tested! \n \n");

    LoadImage(fname,R,G,B);
    AddBorder(R,G,B, "yellow", 64);
    strcpy(sname,"border");
    SaveImage(sname,R,G,B);
    printf("Border tested! \n \n");

}






/* EOF */
