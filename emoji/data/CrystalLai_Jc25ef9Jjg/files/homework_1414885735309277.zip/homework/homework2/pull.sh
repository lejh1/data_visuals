#!/bin/bash

scp cllai1@zuma.eecs.uci.edu:~/eecs22/hw2/* ./
