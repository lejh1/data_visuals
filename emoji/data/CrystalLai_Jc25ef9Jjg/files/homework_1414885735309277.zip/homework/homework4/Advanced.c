
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "Advanced.h"
#include "Constants.h" 

/* add noise to the image*/
IMAGE *Noise(IMAGE *image, int n){
    IMAGE *noised = CreateImage(image->W,image->H);
    int rand(void), i ,x, y;
    for(y=0; y< image->H; y++){
        for(x=0; x<image->W;x++){
        SetPixelR(noised,x,y,GetPixelR(image,x,y));
        SetPixelG(noised,x,y,GetPixelG(image,x,y));
        SetPixelB(noised,x,y,GetPixelB(image,x,y));
        }
    }
    
    for(i=0; i< n*image->W *image->H/100; i++){
        x=rand() % image->W;
        y= rand() % image->H;
        SetPixelR(noised, x, y, 255); 
        SetPixelG(noised, x, y, 255); 
        SetPixelB(noised, x, y, 255); 
    }
    DeleteImage(image);
    return noised; 
}

/* sharpen the image */
IMAGE *Sharpen(IMAGE *image){
    IMAGE *sharpened = CreateImage(image->W,image->H);   
    int             x, y, m, n, a, b;
    int  tmpR[image->W][image->H], tmpG[image->W][image->H], tmpB[image->W][image->H];
    
    int HEIGHT= image->H;
    int WIDTH =image->W;
    
    for (y = 0; y < image->H; y++){
        for (x = 0; x < image->W; x++) {
            tmpR[x][y] = (int) GetPixelR( image, x,y);
            tmpG[x][y] = (int) GetPixelG(image,x,y);
            tmpB[x][y] = (int) GetPixelB(image,x,y);
        }
    }
    int sumR = 0;   /* sum of the intensity differences with neighbors */
    int sumG = 0;
    int sumB = 0;
    for (y =0; y < image->H ; y++){
        for (x = 0; x < image->W ; x++){
            for (n = -1; n <= 1; n++){
                for (m = -1; m <= 1; m++) {
                    a= x+m;
                    b =y +n;
                    if (a  >  WIDTH-1) a = WIDTH - 1;
                    if (a < 0) a =0;
                    if (b > HEIGHT -1) b= HEIGHT -1;
                    if (b< 0) b =0;
                    if (( n==0) && (m==0)) 
                    {
                        sumR += 9*tmpR[a][b];
                        sumG += 9*tmpG[a][b];
                        sumB += 9*tmpB[a][b];
                    }
                    else {
                    sumR -= tmpR[a][b];
                    sumG -= tmpG[a][b];
                    sumB -= tmpB[a][b];
                    }
                }
            }
            SetPixelR(sharpened, x, y, (sumR > MAX_PIXEL) ? MAX_PIXEL: (sumR < 0) ? 0: sumR);
            SetPixelG(sharpened,x,y, (sumG > MAX_PIXEL) ? MAX_PIXEL: (sumG < 0) ? 0: sumG);
            SetPixelB(sharpened,x,y,(sumB > MAX_PIXEL) ? MAX_PIXEL: (sumB < 0) ? 0: sumB);
            sumR = sumG = sumB = 0;
        }
    }
    /* set all four borders to 0 */
    for (y = 0; y < HEIGHT; y++) {
        SetPixelR(sharpened, 0,y, 0);
        SetPixelG(sharpened, 0,y, 0);
        SetPixelB(sharpened, 0,y, 0);
        SetPixelR(sharpened, image->W - 1,y, 0);
        SetPixelG(sharpened, image->W - 1,y, 0);
        SetPixelB(sharpened, image->W - 1,y, 0);
    }
    for (x = 0; x < WIDTH; x++) {
        SetPixelR(sharpened, x,0, 0);
        SetPixelG(sharpened, x,0, 0);
        SetPixelB(sharpened, x,0, 0);
        SetPixelR(sharpened, x,image->H -1, 0);
        SetPixelG(sharpened, x,image->H -1, 0);
        SetPixelB(sharpened, x,image->H-1, 0);
    }

    DeleteImage(image);
    return sharpened;
}

/* posterize the image */
IMAGE *Posterize(IMAGE *image, int rbits, int gbits, int bbits){
    IMAGE *posterized = CreateImage(image->W,image->H );
    int HEIGHT=image->H;
    int WIDTH = image->W;
    int x, y;
    for(y=0; y <HEIGHT; y++){
        for(x=0; x<WIDTH; x++){
           SetPixelR(posterized, x, y, (((GetPixelR(image,x,y) >> rbits << rbits) | (1 << (rbits-1)) ) - 1)) ;
           SetPixelG(posterized, x, y, (((GetPixelG(image,x,y) >> gbits << gbits) | (1 << (gbits-1)) ) - 1)) ;
           SetPixelB(posterized,x,y, (((GetPixelB(image,x,y) >> bbits << bbits) | (1 << (bbits-1)) ) - 1) );
        }
   }
    DeleteImage(image);
    return posterized;
}

/* motion blur */
IMAGE *MotionBlur(IMAGE *image, unsigned char BlurAmount)
{
    IMAGE *motionblurred = CreateImage(image->W, image->H);
    int x, y, i, count=0;
    unsigned int temp_r, temp_g, temp_b;
    int HEIGHT= image->H;
    int WIDTH = image->W;

    for(y=0; y< HEIGHT; y++){
        for(x=0; x< WIDTH; x++){
                temp_r = GetPixelR(image, x, y)/2;
                temp_g = GetPixelG(image, x, y)/2;
                temp_b = GetPixelB(image, x, y)/2;
            
            count=1;
            for(i=1; i <= BlurAmount; i++){
                if(x+i < WIDTH){
                count++;
                temp_r += GetPixelR(image, x+i, y) * .5/BlurAmount;
                temp_g += GetPixelG(image, x+i, y) * .5/BlurAmount;
                temp_b += GetPixelB(image, x+i, y) * .5/BlurAmount;
                }
            }
            SetPixelR(motionblurred, x, y,temp_r);
            SetPixelG(motionblurred, x, y,temp_g);
            SetPixelB(motionblurred, x, y,temp_b);
        }
    }
    DeleteImage(image);
    return motionblurred;
}

IMAGE *Crop(IMAGE *image, int x, int y, int W, int H){
    if(W > image->W-x) W=image->W-x;
    if(H > image->H-y) H=image->H-y;

    IMAGE *cropped = CreateImage(W,H);
    int i, j;
    for(i=x; i<W+x; i++){
        for(j=y; j < H+y; j++){
            SetPixelR(cropped, i-x, j-y, GetPixelR(image, i, j));
            SetPixelG(cropped, i-x, j-y, GetPixelG(image, i, j));
            SetPixelB(cropped, i-x, j-y, GetPixelB(image, i, j));
        }
    }

    DeleteImage(image);
    return cropped;

}
IMAGE *Resize(IMAGE *image, int percentage){
    int W, H;
    int x=0, y=0;
    int i=0, j=0;
    W = image->W * (percentage/100.00);
    H = image->H * (percentage/100.00);
    IMAGE *resized = CreateImage(W,H);
    if(percentage > 100){
        for (x=0; x<W; x++) {
            for (y =0; y<H; y++) {
                i = x / ((double)percentage / 100.0);
                j = y / ((double)percentage / 100.0);
                SetPixelR(resized, x, y, GetPixelR(image, i, j));
                SetPixelG(resized, x, y, GetPixelG(image, i, j));
                SetPixelB(resized, x, y, GetPixelB(image, i, j));
            }
        }
    } else if (percentage<100){
        int x1=0,x2=0,y1=0,y2=0;
        for(x=0; x<W; x++){
            for(y=0; y<H; y++){
                int sum_r=0;
                int sum_g=0;
                int sum_b=0;
                x1= x / ((double)percentage/100.00);
                y1= y / ((double)percentage/100.00);
                x2= (x+1) / ((double)percentage/100.00);
                y2= (y+1) / ((double)percentage/100.00);
               for(i=x1; i<x2; i++){
                   for(j=y1; j<y2; j++){
                       sum_r+= GetPixelR(image, i, j);
                       sum_g+= GetPixelG(image, i, j);
                       sum_b+= GetPixelB(image, i, j);
                   }
               }
                sum_r /= (x2-x1)*(y2-y1);
                sum_g /= (x2-x1)*(y2-y1);
                sum_b /= (x2-x1)*(y2-y1);
                SetPixelR(resized, x, y, sum_r);
                SetPixelG(resized, x, y, sum_g);
                SetPixelB(resized, x, y, sum_b);
            }
        }
    }
    DeleteImage(image);
    return resized;
}
IMAGE *BrightnessAndContrast(IMAGE *image, int brightness, int contrast){
    double factor;
    int new_r, new_g, new_b, x, y;
    
    IMAGE *bandc = CreateImage(image->W,image->H);

    if (brightness> 255) brightness= 255;
    if (brightness < -255) brightness= -255;
    if (contrast > 255) contrast = 255;
    if (contrast < -255) contrast = -255;

    factor = (double) (259 * (contrast + 255)) / (double) (255 * (259 - contrast));
    for(x=0; x< image->W; x++){
        for(y=0; y<image->H; y++){  
            
            SetPixelR(bandc, x, y, GetPixelR(image,x,y)); 
            SetPixelG(bandc, x, y, GetPixelG(image,x,y)); 
            SetPixelB(bandc, x, y, GetPixelB(image,x,y)); 
            
            new_r = (int) (factor * ( GetPixelR(image, x , y) - 128) +128) + brightness;
            new_g = (int) (factor * ( GetPixelG(image, x , y) - 128) +128) + brightness;
            new_b = (int) (factor * ( GetPixelB(image, x , y) - 128) +128) + brightness;
            if (new_r < 0) new_r = 0;
            if (new_r > 255 ) new_r = 255;
            if (new_g < 0) new_g = 0;
            if (new_g > 255 ) new_g = 255;
            if (new_b < 0) new_b = 0;
            if (new_b > 255 ) new_b = 255;

            SetPixelR(bandc, x, y,new_r); 
            SetPixelG(bandc, x, y,new_g); 
            SetPixelB(bandc, x, y,new_b); 
        }
    }
    DeleteImage(image);
    return bandc; 
}

IMAGE *Watermark(IMAGE *image, const IMAGE *watermark_image){
    IMAGE *watermarked = CreateImage(image->W, image->H); 
    int x,y;
    for(x=0; x<image->W; x++){
        for(y=0; y<image->H; y++){
            if(GetPixelR(watermark_image, x%watermark_image->W, y%watermark_image->H)==0 && GetPixelG(watermark_image, x%watermark_image->W, y%watermark_image->H)==0 && GetPixelB(watermark_image, x%watermark_image->W, y%watermark_image->H)==0){
                if( 1.45*GetPixelR(image,x,y) >255){
                    SetPixelR(watermarked, x,y,255);
                }else if ( 1.45*GetPixelR(image,x,y) <255){
                    SetPixelR(watermarked, x, y,  1.45* GetPixelR(image,x,y));
                }
                if(1.45*GetPixelG(image,x,y) >255){
                    SetPixelG(watermarked, x,y,255);
                }else if ( 1.45*GetPixelG(image,x,y) <255){
                    SetPixelG(watermarked, x, y,  1.45* GetPixelG(image,x,y));
                }
                if(1.45*GetPixelB(image,x,y) >255){
                    SetPixelB(watermarked, x,y,255);
                }else if ( 1.45*GetPixelB(image,x,y) <255){
                    SetPixelB(watermarked, x, y,  1.45* GetPixelB(image,x,y));
                }
            }
            else{
                SetPixelR(watermarked,x,y,GetPixelR(image,x,y));
                SetPixelG(watermarked,x,y,GetPixelG(image,x,y));
                SetPixelB(watermarked,x,y,GetPixelB(image,x,y));
            }

        }
    }
    DeleteImage(image);
    return watermarked;
}

