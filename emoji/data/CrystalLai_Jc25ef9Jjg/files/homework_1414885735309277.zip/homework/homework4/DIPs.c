
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "DIPs.h"
#include "Constants.h" 

/* make the picture color black & white */
IMAGE *BlackNWhite(IMAGE *image)
{
    int             x, y, tmp;
    int HEIGHT=image->H;
    int WIDTH= image->W;
    IMAGE *blacknwhited = CreateImage(image->W,image->H);
    for (y = 0; y < HEIGHT; y++)
    {   
        for (x = 0; x < WIDTH; x++) 
        {
            tmp = (GetPixelR(image, x, y) + GetPixelG(image, x, y) + GetPixelB(image, x, y))/3;
            SetPixelR(blacknwhited, x, y, tmp);
            SetPixelG(blacknwhited, x, y, tmp);
            SetPixelB(blacknwhited, x, y, tmp);
        }
    }
    DeleteImage(image);
    return blacknwhited;
}

/* reverse image color */
IMAGE *Negative(IMAGE *image) {
    IMAGE *negatived = CreateImage(image->W,image->H);
    int x, y;
    for (y = 0; y < image->H; y++) {
        for (x = 0; x < image->W; x++) {
            SetPixelR(negatived, x, y, MAX_PIXEL - GetPixelR(image, x, y) );
            SetPixelG(negatived, x, y, MAX_PIXEL - GetPixelG(image, x, y) );
            SetPixelB(negatived, x, y, MAX_PIXEL - GetPixelB(image, x, y) );
            }
    }
    DeleteImage(image);
    return negatived;
}

IMAGE *ColorFilter (IMAGE *image, int target_r, int target_g, int target_b, int threshold, int replace_r, int replace_g, int replace_b) {
    replace_r = (replace_r > MAX_PIXEL)? MAX_PIXEL : (replace_r < 0) ? 0 : replace_r;
    replace_g = (replace_g > MAX_PIXEL)? MAX_PIXEL : (replace_g < 0) ? 0 : replace_g;
    replace_b = (replace_b > MAX_PIXEL)? MAX_PIXEL : (replace_b < 0) ? 0 : replace_b;
    int x, y;
    IMAGE *colorfiltered = CreateImage(image->W,image->H);
    for (y = 0; y < image->H; y++){
        for (x = 0; x < image->W; x++){
            if ((int) GetPixelR(image,x,y) >= target_r -threshold && (int)GetPixelR(image,x,y) <= target_r + threshold
                    && (int) GetPixelG(image,x,y) >= target_g -threshold && (int)GetPixelG(image,x,y) <= target_g + threshold
                    &&(int) GetPixelB(image,x,y) >= target_b -threshold && (int)GetPixelB(image,x,y) <= target_b + threshold
                    ){
                SetPixelR(colorfiltered, x, y, replace_r);
                SetPixelG(colorfiltered, x, y, replace_g);
                SetPixelB(colorfiltered, x, y, replace_b);
            }
            else{
                SetPixelR(colorfiltered, x, y, GetPixelR(image,x,y));
                SetPixelG(colorfiltered, x, y, GetPixelG(image,x,y));
                SetPixelB(colorfiltered, x, y, GetPixelB(image,x,y));
            }
        }
    }
    DeleteImage(image);
    return colorfiltered;
}

IMAGE *Edge(IMAGE *image) 
{
    int             x, y, m, n, a, b;
    int  tmpR[image->W][image->H], tmpG[image->W][image->H], tmpB[image->W][image->H];
    
    IMAGE *edged = CreateImage(image->W,image->H);
    for (y = 0; y < image->H; y++){
        for (x = 0; x < image->W; x++) {
            tmpR[x][y] = (int) GetPixelR( image, x,y);
            tmpG[x][y] = (int) GetPixelG(image,x,y);
            tmpB[x][y] = (int) GetPixelB(image,x,y);
        }
    }
    int sumR = 0;   /* sum of the intensity differences with neighbors */
    int sumG = 0;
    int sumB = 0;
    for (y = 1; y < image->H - 1; y++){
        for (x = 1; x < image->W - 1; x++){
            for (n = -1; n <= 1; n++){
                for (m = -1; m <= 1; m++) {
                    a = (x + m >= image->W) ? image->W - 1 : (x + m < 0) ? 0 : x + m;
                    b = (y + n >= image->H) ? image->H - 1 : (y + n < 0) ? 0 : y + n;
                    sumR += (tmpR[x][y] - tmpR[a][b]);
                    sumG += (tmpG[x][y] - tmpG[a][b]);
                    sumB += (tmpB[x][y] - tmpB[a][b]);
                }
            }
            SetPixelR(edged, x, y, (sumR > MAX_PIXEL) ? MAX_PIXEL: (sumR < 0) ? 0: sumR);
            SetPixelG(edged,x,y, (sumG > MAX_PIXEL) ? MAX_PIXEL: (sumG < 0) ? 0: sumG);
            SetPixelB(edged,x,y,(sumB > MAX_PIXEL) ? MAX_PIXEL: (sumB < 0) ? 0: sumB);
            sumR = sumG = sumB = 0;
        }
    }
    /* set all four borders to 0 */
    for (y = 0; y < image->H; y++) {
        SetPixelR(edged, 0,y, 0);
        SetPixelG(edged, 0,y, 0);
        SetPixelB(edged, 0,y, 0);
        SetPixelR(edged, image->W - 1,y, 0);
        SetPixelG(edged, image->W - 1,y, 0);
        SetPixelB(edged, image->W - 1,y, 0);
    }
    for (x = 0; x < image->W; x++) {
        SetPixelR(edged, x,0, 0);
        SetPixelG(edged, x,0, 0);
        SetPixelB(edged, x,0, 0);
        SetPixelR(edged, x,image->H -1, 0);
        SetPixelG(edged, x,image->H -1, 0);
        SetPixelB(edged, x,image->H-1, 0);
    }
    DeleteImage(image);
    return edged;
}

/* flip image vertically */
IMAGE *VFlip(IMAGE *image)
{
    int             x, y;
    unsigned char   r, g, b;
    int HEIGHT= image->H;
    int WIDTH = image->W;
    IMAGE *flipped = CreateImage(image->W, image->H);

    for (y = 0; y <= HEIGHT/2; y ++) 
    {
        for (x = 0; x < WIDTH; x ++) 
        {
            r = GetPixelR(image,x , HEIGHT - 1 - y);
            g = GetPixelG(image,x , HEIGHT - 1 - y);
            b = GetPixelB(image,x , HEIGHT - 1 - y);
            
            SetPixelR(flipped, x , HEIGHT - 1 - y, GetPixelR(image,x,y));
            SetPixelG(flipped, x , HEIGHT - 1 - y, GetPixelG(image,x,y));
            SetPixelB(flipped, x , HEIGHT - 1 - y, GetPixelB(image,x,y));
            
            SetPixelR(flipped,x,y,r);
            SetPixelG(flipped,x,y,g);
            SetPixelB(flipped,x,y,b);
        }
    }
    DeleteImage(image);
    return flipped;
}

/* mirror image vertically */
IMAGE *VMirror(IMAGE *image) {
    int x, y;
    int HEIGHT= image->H;
    int WIDTH=image->W;
    IMAGE *mirrored = CreateImage(image->W, image->H);
    for (y = 0; y < HEIGHT / 2; y ++) {
        for (x = 0; x < WIDTH; x ++) {
            SetPixelR(mirrored, x, y, GetPixelR(image,x,y));
            SetPixelG(mirrored, x, y, GetPixelG(image,x,y));
            SetPixelB(mirrored, x, y, GetPixelB(image,x,y));
            SetPixelR(mirrored, x, HEIGHT-1-y, GetPixelR(image,x,y));
            SetPixelG(mirrored, x, HEIGHT-1-y, GetPixelG(image,x,y));
            SetPixelB(mirrored, x, HEIGHT-1-y, GetPixelB(image,x,y));
        }
    }
    DeleteImage(image);
    return mirrored;
}

/* Shuffle the image */
IMAGE *Shuffle(IMAGE *image)
{
    int HEIGHT=image->H;
    int WIDTH= image->W;
    IMAGE* shuffled = CreateImage(image->W, image->H);

    int block_cnt = SHUFF_HEIGHT_DIV * SHUFF_WIDTH_DIV;
    int block_width = WIDTH/SHUFF_WIDTH_DIV;
    int block_height = HEIGHT/SHUFF_HEIGHT_DIV;
    int block[SHUFF_WIDTH_DIV][SHUFF_HEIGHT_DIV];
    int i, j;
    

    srand(time(NULL));
    /* Initialize block markers to not done (-1) */
    for (i = 0; i < SHUFF_WIDTH_DIV; i++) {
        for (j = 0; j< SHUFF_HEIGHT_DIV; j++) {
            block[i][j] = -1;
        }
    }
    
    for(i=0; i<image->W;i++){
        for(j=0; j<image->H;j++){
            SetPixelR(shuffled, i,j, GetPixelR(image,i,j));
            SetPixelG(shuffled, i,j, GetPixelG(image,i,j));
            SetPixelB(shuffled, i,j, GetPixelB(image,i,j));
        }
    }


    while (block_cnt > 0) {
        /* Generate a random pair of blocks */
        int dest_height = rand() % SHUFF_HEIGHT_DIV;
        int dest_width = rand() % SHUFF_WIDTH_DIV;
        int src_height = rand() % SHUFF_HEIGHT_DIV;
        int src_width = rand() % SHUFF_WIDTH_DIV;

        /* Check if these blocks are already swaped, if not swap blocks */
        if ((block[dest_width][dest_height] == -1) && (block[src_width][src_height] == -1)) {
            /* Swap blocks */
            for (i = 0; i < block_height; i++) {
                /* Init src and dest height offset */
                int h_dest = ((dest_height * block_height) + i) % HEIGHT;
                int h_src  = ((src_height * block_height) + i) % HEIGHT; 
                for (j = 0; j < block_width; j++) {
                    /* Init src and dest width offset */
                    int w_src  = ((src_width * block_width) + j) % WIDTH; 
                    int w_dest = ((dest_width * block_width) + j) % WIDTH;

                    SetPixelR(shuffled, w_dest,h_dest, GetPixelR(image, w_src, h_src));
                    SetPixelR(shuffled, w_src, h_src, GetPixelR(image, w_dest, h_dest));

                    SetPixelG(shuffled, w_dest,h_dest, GetPixelR(image, w_src, h_src));
                    SetPixelG(shuffled, w_src, h_src, GetPixelR(image, w_dest, h_dest));

                    SetPixelB(shuffled, w_dest,h_dest, GetPixelB(image, w_src, h_src));
                    SetPixelB(shuffled, w_src, h_src, GetPixelB(image, w_dest, h_dest));
                }
            }
            /* Set marker as done */
            block[dest_width][dest_height] = 1;
            block[src_width][src_height] = 1;
            /* Decrease block count */
            block_cnt -= 2; /* Two blocks are swapped */
        }
        
    }
    DeleteImage(image);
    return shuffled;
}

/* add border to the image */
IMAGE *AddBorder(IMAGE *image, char *color, int border_width) {
    int x, y;
    int HEIGHT= image->H;
    int WIDTH = image->W;
    IMAGE* bordered = CreateImage(image->W, image->H);

    int border_r = 255;
    int border_g = 255;
    int border_b = 255;
    if (!strcmp(color, "black")) {
        border_r = 0;
        border_g = 0;
        border_b = 0;
    } else if (!strcmp(color, "white")) {
        border_r = 255;
        border_g = 255;
        border_b = 255;
    } else if (!strcmp(color, "red")) {
        border_r = 255;
        border_g = 0;
        border_b = 0;
    } else if (!strcmp(color, "green")) {
        border_r = 0;
        border_g = 255;
        border_b = 0;
    } else if (!strcmp(color, "blue")) {
        border_r = 0;
        border_g = 0;
        border_b = 255;
    } else if (!strcmp(color, "yellow")) {
        border_r = 255;
        border_g = 255;
        border_b = 0;
    } else if (!strcmp(color, "cyan")) {
        border_r = 0;
        border_g = 255;
        border_b = 255;
    } else if (!strcmp(color, "pink")) {
        border_r = 255;
        border_g = 192;
        border_b = 203;
    } else if (!strcmp(color, "orange")) {
        border_r = 255;
        border_g = 165;
        border_b = 0;
    } else {
        printf("Unsurported color.\n");
        return NULL;
    }
    const int X_BORDER_WIDTH = border_width * 9 / 16;
    for (y = 0; y < HEIGHT; y++) {
        for (x = 0; x < WIDTH; x++) {
                SetPixelR(bordered,x,y, GetPixelR(image,x,y));
                SetPixelG(bordered,x,y, GetPixelG(image,x,y));
                SetPixelB(bordered,x,y, GetPixelB(image,x,y));
            if ((y < border_width) || (y > HEIGHT - 1 - border_width) ||
                    (x < X_BORDER_WIDTH) || (x > WIDTH - 1 - X_BORDER_WIDTH)) {
                SetPixelR(bordered,x,y, border_r);
                SetPixelG(bordered,x,y, border_g);
                SetPixelB(bordered,x,y, border_b);
            }
        }
    }
    DeleteImage(image);
    return bordered;
}

