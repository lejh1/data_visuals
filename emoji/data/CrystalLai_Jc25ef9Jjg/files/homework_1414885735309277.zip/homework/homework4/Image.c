#include "Image.h"
#include <stdlib.h>
#include <assert.h>

/* Get the R intensity of pixel (x, y) in image */
unsigned char GetPixelR(const IMAGE *image, unsigned int x,  unsigned int y) {
    return image->R[y * image->W + x];
}

/* Get the G intensity of pixel (x, y) in image */
unsigned char GetPixelG(const IMAGE *image, unsigned int x,  unsigned int y) {
    return image->G[y * image->W + x];
}

/* Get the B intensity of pixel (x, y) in image */
unsigned char GetPixelB(const IMAGE *image, unsigned int x,  unsigned int y) {
    return image->B[y*image->W+x];
}

/* Set the R intensity of pixel (x, y) in image to r */
void SetPixelR(IMAGE *image, unsigned int x,  unsigned int y, unsigned char r) {
    image->R[y*image->W+x] = r;
}

/* Set the G intensity of pixel (x, y) in image to g */
void SetPixelG(IMAGE *image, unsigned int x,  unsigned int y, unsigned char g) {
    image->G[y*image->W+x] = g;
}

/* Set the B intensity of pixel (x, y) in image to b */
void SetPixelB(IMAGE *image, unsigned int x,  unsigned int y, unsigned char b) {
    image->B[y*image->W+x] = b;
}


/* Allocate dynamic memory for the image structure and its R/G/B values */
/* Return the pointer to the image, or NULL in case of error */
IMAGE *CreateImage(unsigned int WIDTH, unsigned int HEIGHT) {
    IMAGE *image = malloc(sizeof(IMAGE));
    image->R = malloc(WIDTH*HEIGHT*sizeof(unsigned char));
    image->G = malloc(WIDTH*HEIGHT*sizeof(unsigned char));
    image->B = malloc(WIDTH*HEIGHT*sizeof(unsigned char));
    image->H = HEIGHT;
    image->W = WIDTH;
    return image; 
}

/* Free the memory for the R/G/B values and IMAGE structure */
void DeleteImage(IMAGE *image) {
    if (image != NULL) {
        assert(image->R);
        free(image->R);
        assert(image->G);
        free(image->G);
        assert(image->B);
        free(image->B);
        assert(image);
        free(image);
    }
}

/* Return the image's width in pixels */
unsigned int ImageWidth(const IMAGE *image) {
    return image->W;
}

/* Return the image's height in pixels */
unsigned int ImageHeight(const IMAGE *image) {
    return image->H;
}
