/*Crystal is my name*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <assert.h>

#include "Advanced.h"
#include "DIPs.h"
#include "FileIO.h"
#include "Constants.h" 
#include "Image.h"
#include "Test.h"
void PrintMenu();

/* Test all functions */


int main() {

    IMAGE* image = NULL;

#ifdef DEBUG
    AutoTest();
#endif

#ifndef DEBUG
    
    IMAGE* result =NULL;

    int option;			/* user input option */
    char fname[SLEN];		/* input file name */
    char colorOption[SLEN];
    int rc = -1;			/* return code of ReadImage() */
    /* ColorFilter() parameters */
    int target_r=0, target_g=0, target_b=0, threshold=0;
    int factor_r=0, factor_g=0, factor_b=0;
    /* AddBorder() parameter */
    int border_width;
    /*Noise() parameter*/
    int n=0;
    srand(time(NULL));
    /*Posterize() parameters */
    unsigned int rbits=0;
    unsigned int gbits=0;
    unsigned int bbits=0;
    /*MotionBlur() parameter*/
    int BlurAmount;
    /*Crop() parameter*/
    int x, y, W, H;
    /*Resize() pamareter*/
    int percentage;
    /*BandC ()parameters*/
    int brightness, contrast;
    /*Watermark() parameters*/



    PrintMenu();
    printf("Please make your choice: ");
    scanf("%d", &option);

    while (option != EXIT) {
        if (option == 1) {
            printf("Please input the file name to load: ");
            scanf("%s", fname);
            image = LoadImage(fname);
        }
        /* menu item 2 - 10 requires image is loaded first */
        else if (option >= 2 && option <= 18) {
            if (image == NULL) {
                rc = -1;
            } else {
                rc = SUCCESS;
            }
            if (rc != SUCCESS)	 {
                printf("No image is read.\n");
            }
            /* now image is loaded */
            else {
                switch(option) {
                    case 2:
                        printf("Please input the file name to save: ");
                        scanf("%s", fname);
                        break;
                    case 3:
                        result  = BlackNWhite(image);
#ifdef DEBUG
                        printf("\"Black & White\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;
					case 4:
                        result = Negative(image);
#ifdef DEBUG
                        printf("\"Negative\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;
                    case 5:
                        printf("Enter Red   component for the target color: ");
                        scanf("%d", &target_r);
                        printf("Enter Green component for the target color: ");
                        scanf("%d", &target_g);
                        printf("Enter Blue  component for the target color: ");
                        scanf("%d", &target_b);
                        printf("Enter threshold for the color difference: ");
                        scanf("%d", &threshold);
                        printf("Enter value for Red component in the target color: ");
                        scanf("%d", &factor_r);
                        printf("Enter value for Green component in the target color: ");
                        scanf("%d", &factor_g);
                        printf("Enter value for Blue  component in the target color: ");
                        scanf("%d", &factor_b);
						
                        result = ColorFilter(image, target_r, target_g, target_b, threshold, factor_r, factor_g, factor_b);
#ifdef DEBUG
                        printf("\"Color Filter\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;
                    case 6:
                        result =  Edge(image);
#ifdef DEBUG
                        printf("\"Edge\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;
                    case 7:
                        result = Shuffle(image);
#ifdef DEBUG
                        printf("\"Shuffle\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;
					case 8:
                         result = VFlip(image);
#ifdef DEBUG
                        printf("\"VFlip\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;
					case 9:
                        result = VMirror(image);
#ifdef DEBUG
                        printf("\"Vertically Mirror\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;
                    case 10:
                        printf("Enter border width:");
                        scanf("%d", &border_width);
                        printf("Available border colors : black, white, red, green, blue, yellow, cyan, pink, orange\n");
                        printf("Select border color from the options: ");
                        scanf("%s",colorOption);
                        result = AddBorder(image, colorOption, border_width);
#ifdef DEBUG
                        printf("\"Border\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;
                    case 11:
                        printf("Please input noise percentage:");
                        scanf(" %d", &n);
                        result = Noise(image, n);
#ifdef DEBUG
                        printf("\"Noise\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;
                    case 12:
                        result = Sharpen(image);
#ifdef DEBUG
                        printf("\"Sharpen\" operation is done!\n");
#endif
                        image = NULL;
                        image = result;
                        break;

                    case 13:
                        printf("Enter the number of posterization bits for R channel (1 to 8):");
                        scanf(" %d", &rbits);
                        printf("Enter the number of posterization bits for G channel (1 to 8):");
                        scanf(" %d", &gbits);
                        printf("Enter the number of posterization bits for B channel (1 to 8):");
                        scanf(" %d", &bbits);

                        result = Posterize(image,rbits,gbits,bbits);
                        
#ifdef DEBUG
                        printf("\"Posterize\" operation is done!");
#endif
                        image = NULL;
                        image = result;
                        break;

                    case 14:
                       printf("Please input blur amount:");
                       scanf(" %d",&BlurAmount);
                       result = MotionBlur(image, BlurAmount);
#ifdef DEBUG
                       printf("\"motionblur\" operation is done!");
#endif
                        image = NULL;
                        image = result;
                        break;
                   case 15:
                       printf("Please enter the X offset value:");
                       scanf("%d", &x);
                       printf("Please enter the Y offset value:");
                       scanf("%d", &y);
                       printf("Please input the crop width:");
                       scanf("%d", &W);
                       printf("Please input the crop height:");
                       scanf("%d", &H);
                       result  = Crop(image, x, y, W,H);
#ifdef DEBUG
                       printf("\"Crop\" operation is done!");
#endif
                        image = NULL;
                        image = result;
                        break;

                   case 16:
                       printf("Please input the resizing percentage(integer between 1 - 500):");
                       scanf("%d", &percentage);
                       result = Resize(image, percentage);
#ifdef DEBUG
                       printf("\"Resizing the image\" operation is done!");
#endif
                        image = NULL;
                        image = result;
                        break; 
                   case 17:
                        printf("Please input the brightness level (integer between -255 -255):");
                        scanf("%d", &brightness);
                        printf("Please input the contrast level (integer between -255-255):");
                        scanf("%d", &contrast);
                        result = BrightnessAndContrast(image, brightness,contrast);

#ifdef DEBUG
                       printf("\"Brightness and Contrast Adjustment\" operation is done!");
#endif
                        image = NULL;
                        image = result;

                        break;
                   case 18:   
                        printf("Please load Watermark:");
                        scanf("%s", fname);
                        IMAGE*  watermark_image = CreateImage(W,H); 
                        watermark_image =LoadImage(fname);
                        result = Watermark(image, watermark_image);
#ifdef DEBUG
                        printf("\"Watermark\" operation is done!");
#endif
                        image =NULL;
                        image =result;

                        break;
                        
                    default:
                        break;
                }
            }
        }
        else if (option == 19) {
            DeleteImage(image);
            image = NULL;
            AutoTest();
            rc = SUCCESS;	/* set returned code SUCCESS, since image is loaded */
            image = NULL;
        }
        else {
            printf("Invalid selection!\n");
        }

        /* Process finished, waiting for another input */
        PrintMenu();
        printf("Please make your choice: ");
        scanf("%d", &option);
    }
#endif
    printf("You exit the program.\n");
    DeleteImage(image);
    image = NULL;
    return 0;
}



void PrintMenu() {
    printf("\n----------------------------\n");
    printf(" 1: Load a PPM image\n");
    printf(" 2: Save an image in PPM and JPEG format\n");
    printf(" 3: Change a color image to Black & White\n");
    printf(" 4: Make a negative of an image\n");
    printf(" 5: Color filter an image\n");
    printf(" 6: Sketch the edge of an image\n");
    printf(" 7: Shuffle an image\n");
    printf(" 8: Flip an image vertically\n");
    printf(" 9: Mirror an image vertically\n");
    printf("10: Add border to an image\n");
    printf("11: Add noise to an image\n");
    printf("12:Sharpen an image\n");
    printf("13:Posterize an image\n");
    printf("14:Motion Blur\n");
    printf("15:Crop an images\n");
    printf("16:Resize an image\n");
    printf("17:Adjust the Brightness and Contrast of an image\n");
    printf("18:Add Watermark to an image\n");
    printf("19:Test all functions\n");
    printf("20:Exit\n");
}

