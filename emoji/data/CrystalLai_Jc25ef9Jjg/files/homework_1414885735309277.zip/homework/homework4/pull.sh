#!/bin/bash

scp cllai1@bondi.eecs.uci.edu:~/eecs22/hw4/* ./
