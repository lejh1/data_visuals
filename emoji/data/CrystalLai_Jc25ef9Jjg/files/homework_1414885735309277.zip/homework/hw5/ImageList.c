/*********************************************************************/
/* Homework Assignment 5, for EECS 22, Fall 2017                     */
/*                                                                   */
/* Author: Tim Schmidt                                               */
/* Date: 11/09/2017                                                  */
/*                                                                   */
/* ImageList.c: source file for image list manipulations             */
/*                                                                   */
/*********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "ImageList.h"

/* Create a new image list */
ILIST *CreateImageList(void)
{
    ILIST *list;
    list = malloc(sizeof(ILIST));
    if(!list){
        perror("Out of Memory! Aborting...");
        exit(10);
    }
    list->Length = 0;
    list->First = NULL;
    list->Last = NULL;
    return list;
}

/* Delete an image list (and all entries) */
void DeleteImageList(ILIST *list)
{
    IENTRY *curr, *next;
    assert(list);
    curr = list->First;
    next = NULL;

    while(curr){   
        next = curr->Next; 
        if(curr->RGBImage)
        DeleteImage(curr->RGBImage);
        if(curr->YUVimage)
        DeleteYUVImage(curr->YUVimage);
        
        free(curr);
        curr = next;
    }
    free(list);
    /* to be implemented */
}

/* Insert a RGB image to the image list at the end */
void AppendRGBImage(ILIST *list, IMAGE *RGBImage)
{
    assert(list);
    list->Last->Next = malloc(sizeof(IENTRY));  
    list->Last->Next->RGBImage = RGBImage;
    list->Last->Next->YUVimage = NULL;
    list->Last->Next->Next = NULL;
    list->Length++;
    list->Last->Next->Prev = list->Last;
    list->Last->Next->List = list;
    list->Last = list->Last->Next; 
     
}

/* Insert a YUV image to the image list at the end */
void AppendYUVImage(ILIST *list, YUVIMAGE *YUVimage)
{
    assert(list);
    list->Last->Next = malloc(sizeof(IENTRY));  
    list->Last->Next->YUVimage = YUVimage;
    list->Last->Next->Next = NULL;
    list->Last->Next->RGBImage = NULL;
    list->Length++; 
    list->Last->Next->Prev = list->Last;
    list->Last->Next->List = list;
    list->Last = list->Last->Next; 

}

/* Crop an image list */
void CropImageList(ILIST *list, unsigned int start, unsigned int end)
{
    int x;
    IENTRY *next, *current;
    assert(list);
    for(x=0; x <start; x++){
        next = list->First->Next; 
        DeleteYUVImage(list->First->YUVimage);
        if(list->First->RGBImage)
        DeleteImage(list->First->RGBImage);
        list->First = next;
    }
    current = list->First; 
    for(x=start; x<=end; x++){
        current = current->Next;
    }
    list->Last = current->Prev; 
    while(current){
        next = current->Next;
        if(current->RGBImage)
        DeleteImage(current->RGBImage);
        current->RGBImage =NULL;
        if(current->YUVimage)
        DeleteYUVImage(current->YUVimage);
        current->YUVimage =NULL;
        current = next; 
    }
    list->First->Prev = NULL;
    list->Last->Next = NULL;
    
}

/* Fast forward an image list */
void FastImageList(ILIST *list, unsigned int factor)
{
    int y=0, count=0, deleted=0;
    IENTRY *current, *prev;
    prev = NULL;
    current = list->First;
    
    
    for(y=0; y < list->Length; y++){
           if(current !=NULL){
            if(y % factor != 0){
                IENTRY *next = current->Next;    
                if (next != NULL) {
                    next->Prev = prev;
                    prev->Next = next;
                } else {
                    prev->Next = NULL;
                }
                if (current->RGBImage)
                    DeleteImage(current->RGBImage);
                if (current->YUVimage)
                    DeleteYUVImage(current->YUVimage);
                current = next;
                deleted++;
            } else {
                current->Prev = prev;
                prev = current;
                list->Last = current;
                current = current->Next;
                count++;
            }
           }
        }
       
        current= list->First;
        while(current){
            current =list->Last; 
            current= current->Next;        
        }
        
      list->Length -= deleted;
      printf("%d", count); 
}

/* Reverse an image list */
void ReverseImageList(ILIST *list)
{
    IENTRY *curr;
    IENTRY *next;
    curr= list->First;

    while(curr!=NULL){
        next = curr->Next;
        curr->Next = curr->Prev;
        curr->Prev = next;
        curr = next;
    }
        curr= list->First;
        list->First = list->Last;
        list->Last = curr;
}


/* EOF */
