/*********************************************************************/
/* Homework Assignment 5, for EECS 22, Fall 2017                     */
/*                                                                   */
/* Author: Tim Schmidt                                               */
/* Date: 11/09/2017                                                  */
/*                                                                   */
/* Movie.c: source file for basic movie manipulations                */
/*                                                                   */
/*********************************************************************/

#include <stdlib.h>
#include <assert.h>
#include "Movie.h"

/* Allocate the memory space for the movie and the memory space */
/* for the frame list. Return the pointer to the movie. */
MOVIE *CreateMovie(void)
{
    MOVIE *movie = malloc(sizeof(MOVIE));
    if (movie == NULL){
        return NULL;
    }
    movie->Frames = NULL;
    return movie; 
    /* to be implemented */
}

/* Release the memory space for the frame list. */
/* Release the memory space for the movie. */
void DeleteMovie(MOVIE *movie)
{
    assert(movie);
    assert(movie->Frames);

    DeleteImageList(movie->Frames);
    movie->Frames=NULL;

    free(movie);

    /* to be implemented */
}

/* Convert a YUV movie to a RGB movie */
void YUV2RGBMovie(MOVIE *movie)
{
    int C=0, D=0, E=0, i=0, j=0,R=0, G=0, B=0;
    IENTRY *x;
    for(x=movie->Frames->First; x != NULL; x=x->Next){
        if(x->RGBImage!=NULL){
        DeleteImage(x->RGBImage);
        }
        x->RGBImage = CreateImage(x->YUVimage->W, x->YUVimage->H);
        for(i=0; i<x->YUVimage->W ; i++){
            for(j=0; j<x->YUVimage->H ; j++){
                C = (int) GetPixelY(x->YUVimage , i ,j) - 16;
                D = (int) GetPixelU(x->YUVimage,i,j) - 128;
                E = (int) GetPixelV(x->YUVimage,i,j) - 128;
                R =  (298 * C + 409 * E + 128) >> 8; 
                G = (298 * C -100 * D - 208 * E + 128) >> 8;
                B =  (298 * C + 516 * D + 128) >> 8; 
                if (R<0)R=0;
                if(R>255) R=255;
                if(G<0)G=0;
                if(G>255) G=255;
                if(B<0) B=0;
                if(B>255) B=255;
                SetPixelR(x->RGBImage, i, j, R ); 
                SetPixelG(x->RGBImage, i, j, G ); 
                SetPixelB(x->RGBImage, i, j, B ); 
            }
        }
    }
}

/* Convert a RGB movie to a YUV movie */
void RGB2YUVMovie(MOVIE *movie)
{
    int i=0, j=0, Y=0, U=0, V=0, R=0, G=0, B=0;
    IENTRY *x; 
    for(x=movie->Frames->First; x != NULL; x=x->Next){
        if(x->YUVimage)
        DeleteYUVImage(x->YUVimage);
        x->YUVimage = CreateYUVImage(x->RGBImage->W,x-> RGBImage->H);
        for(i=0; i<x->RGBImage->W ; i++){
            for(j=0; j<x->RGBImage->H ; j++){
                if(x->RGBImage->R&&x->RGBImage->G&&x->RGBImage->B)
                R = (int) GetPixelR(x->RGBImage , i ,j);
                if(x->RGBImage->R&&x->RGBImage->G&&x->RGBImage->B)
                G = (int) GetPixelG(x->RGBImage,i,j);
                if(x->RGBImage->R&&x->RGBImage->G&&x->RGBImage->B)
                B = (int) GetPixelB(x->RGBImage,i,j);
                Y = ((( 66 * R + 129 * G + 25 * B + 128) >> 8) +16) ; 
                U = (((-38 * R - 74 * G +112 * B + 128) >> 8) + 128);
                V = (((112 * R - 94 * G - 18 * B + 128) >> 8) +128); 
                if(Y<0)Y=0;
                if(Y>255) Y=255;
                if(U<0)U=0;
                if(U>255) U=255;
                if(V<0) V=0;
                if(V>255) V=255;
                SetPixelY(x->YUVimage, i, j, Y ); 
                SetPixelU(x->YUVimage, i, j, U ); 
                SetPixelV(x->YUVimage, i, j, V ); 
            }
        }
    }
}

/* EOF */
