
#!/bin/bash

scp ./*.c ./*.h Makefile cllai1@zuma.eecs.uci.edu:~/eecs22/hw5
