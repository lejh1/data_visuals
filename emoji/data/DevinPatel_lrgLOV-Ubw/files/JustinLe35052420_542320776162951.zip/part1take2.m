close all;
clear;
clc;

%% Part 1 
b = [4,3,2,1,2,3,4];
n = [0:6];
w = -pi:pi/4:pi;
[X] =dtft(b,n,w);
    
%% magnitude plot
subplot(2,1,1);
plot(w/pi,(abs(X)));
xlabel('w/pi');
ylabel('amplitude');
title('magnitude plot for X(w)');

%% phase plot
subplot(2,1,2);
plot(w/pi, angle(X));
xlabel('w/pi');
ylabel('radians');
title('Phase plot for X(w)');

function [X] = dtft(x,n,w)
    X = x*exp(-j*n'*w);
end