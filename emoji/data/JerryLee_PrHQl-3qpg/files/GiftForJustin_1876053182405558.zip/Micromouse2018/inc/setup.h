#pragma once

void ledSetup();
void motorsSetup();
void encodersSetup();
void receiversSetup();
void emittersSetup();
void initializePinModes();
void attachInterrupts();