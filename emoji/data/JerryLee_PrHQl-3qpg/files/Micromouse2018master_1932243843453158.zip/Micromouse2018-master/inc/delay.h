#pragma once
#include <Arduino.h>

extern elapsedMillis wait_ms;
extern elapsedMicros wait_us;