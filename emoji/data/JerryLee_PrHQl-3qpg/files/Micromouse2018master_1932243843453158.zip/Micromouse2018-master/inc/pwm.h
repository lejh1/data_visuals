#pragma once

extern int leftBaseSpeed;
extern int rightBaseSpeed;
// extern volatile bool startingCell = false;


void setLeftPwm(int);
void setRightPwm(int);