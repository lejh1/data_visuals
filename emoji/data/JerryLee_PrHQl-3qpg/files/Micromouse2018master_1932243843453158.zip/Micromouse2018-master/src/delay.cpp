#include "../inc/delay.h"
#include <Arduino.h>

elapsedMillis wait_ms;
elapsedMicros wait_us;