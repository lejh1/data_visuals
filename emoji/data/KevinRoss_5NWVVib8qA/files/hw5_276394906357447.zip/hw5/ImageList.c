/*********************************************************************/
/* Homework Assignment 5, for EECS 22, Fall 2017                     */
/*                                                                   */
/* Author: Tim Schmidt                                               */
/* Date: 11/09/2017                                                  */
/*                                                                   */
/* ImageList.c: source file for image list manipulations             */
/*                                                                   */
/*********************************************************************/

#include <stdlib.h>
#include <assert.h>
#include "ImageList.h"
#include "Image.h"

/* Create a new image entry */
IENTRY *CreateImageEntry(void)
{
    IENTRY *entry = (IENTRY *)malloc(sizeof(IENTRY));
    if (entry == NULL){
        return NULL;
    }
    // Initialize parameters
    entry->List = NULL;
    entry->Next = NULL;
    entry->RGBImage = NULL;
    entry->YUVImage = NULL;

    return entry;
}

/* Delete image entry (and image objects)*/
void DeleteImageEntry(IENTRY *entry)
{
    assert(entry);
    //Checks for YUV vs RGB
    if (entry->YUVImage !=NULL){
        DeleteYUVImage(entry->YUVImage);
        entry->YUVImage = NULL;
    }
    if (entry->RGBImage !=NULL){
        DeleteImage(entry->RGBImage);
        entry->RGBImage = NULL;
    }

    free(entry);
}

/* Create a new image list */
ILIST *CreateImageList(void)
{
    ILIST *list = (ILIST *)malloc(sizeof(ILIST));
    if (list == NULL){
        return NULL;
    }
    // Initialize parameters
    list->First = NULL;
    list->Last = NULL;
    list->length = 0;
    return list;
}

/* Delete an image list (and all entries) */
void DeleteImageList(ILIST *list)
{
    assert(list);
    assert(list->First);
    assert(list->Last);
    IENTRY *entry = NULL;

    entry = list->First;
    while(entry != list->Last){
        entry = entry->Next;
        DeleteImageEntry(entry->Prev);

    }
    DeleteImageEntry(entry);

    list->First = NULL;
    list->Last = NULL;
    free(list);
    
}

/* Insert a RGB image to the image list at the end */
void AppendRGBImage(ILIST *list, IMAGE *RGBimage)
{
    assert(list);
    assert(RGBimage);

    IENTRY *entry = CreateImageEntry();
    entry->RGBImage = RGBimage;
    entry->List = list;

    // check if list is empty
    if (list->First==NULL){
        list->First = entry;
        list->Last = entry;
        entry->Prev = NULL;
        entry->Next = NULL;
    }
    else{
        entry->Prev = list->Last;
        list->Last->Next = entry;
        entry->Next = NULL;
        list->Last = entry;
    }
    list->length = list->length + 1;
}

/* Insert a YUV image to the image list at the end */
void AppendYUVImage(ILIST *list, YUVIMAGE *YUVimage)
{
    assert(list);
    assert(YUVimage);

    IENTRY *entry = CreateImageEntry();
    entry->YUVImage = YUVimage;
    entry->List = list;

    // check if list is empty
    if (list->First==NULL){
        list->First = entry;
        list->Last = entry;
        entry->Prev = NULL;
        entry->Next = NULL;
    }
    else{
        entry->Prev = list->Last;
        list->Last->Next = entry;
        entry->Next = NULL;
        list->Last = entry;
    }
    list->length = list->length + 1;
}

/* Fast forward an image list */
void FastImageList(ILIST *list, unsigned int factor)
{
	unsigned int newFrameNum = 0;
	unsigned int counter = 0;
	IENTRY *curr = NULL; /* current entry in the list */
	IENTRY *prev = NULL; /* previous kept entry in the list */
	IENTRY *next = NULL; /* next entry in the list */

	assert(list);
	assert(factor > 0);

	curr = list->First;

	while (curr != NULL) {
		next = curr->Next;

		if (counter % factor == 0) {
			newFrameNum ++;

			curr->Prev = prev;
			if (prev != NULL) {
				prev->Next = curr;
			}
			prev = curr;
		} else {
			if (curr->RGBImage != NULL) {
				DeleteImage(curr->RGBImage);
			}

			if (curr->YUVImage != NULL) {
				DeleteYUVImage(curr->YUVImage);
			}

			curr->List = NULL;
			curr->Next = NULL;
			curr->Prev = NULL;
			curr->RGBImage = NULL;
			curr->YUVImage = NULL;
			free(curr);
		}

		curr = next;
		counter ++;
	}

	list->Last = prev;
	if (prev != NULL) {
		prev->Next = NULL;
	}
	list->length = newFrameNum;
}

/* Reverse an image list */ 
void ReverseImageList(ILIST *list)
{
    assert(list);
    IENTRY *entry = NULL;
    IENTRY *curr = list->First;
    list->First = list->Last;
    list->Last = curr;

    // Swap all entries iteratively
    while(curr != NULL)
    {
        entry = curr->Prev;
        curr->Prev = curr->Next;
        curr->Next = entry;
        curr = curr->Prev;
    }
}

/* EOF */
