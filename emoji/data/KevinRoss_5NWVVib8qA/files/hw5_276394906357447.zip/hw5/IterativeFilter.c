/*********************************************************************/
/* Homework Assignment 5, for EECS 22, Fall 2018                     */
/*                                                                   */
/* Author: Jordan Bonecutter                                         */
/*                                                                   */
/* IterativeFilter.c: file for iterative filters                     */
/*                                                                   */
/*********************************************************************/

#include "IterativeFilter.h"
#include "Image.h"
#include "Movie.h"
#include "assert.h"

MOVIE *doIterativeFilter(IMAGE *image, iterableFilter filter, float start, float end, float change)
{
    float step=change;
    float num = start;
    assert(image);
    MOVIE *movie = CreateMovie();
    IMAGE *temp;

    // Reverse step if end < start
    if (end<num){
        step = -change;
    }

    // If step positive
    if(step>0){
        while(num<end){
            temp = CopyImage(image); // Make copy of original image 
            temp = (*filter)(temp, num);
            AppendRGBImage(movie->Frames, temp);
            num += step;
        }
    }

    // If step is negative
    else{
        while(num>end){
            temp = CopyImage(image); // Make copy of original image 
            temp = (*filter)(temp, num);
            AppendRGBImage(movie->Frames, temp);
            num += step;
        }
    }
    RGB2YUVMovie(movie);
    DeleteImage(image); // Delete original image
    return movie;
}
