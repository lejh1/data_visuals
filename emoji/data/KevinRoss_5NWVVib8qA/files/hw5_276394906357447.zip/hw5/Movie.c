/*********************************************************************/
/* Homework Assignment 5, for EECS 22, Fall 2017                     */
/*                                                                   */
/* Author: Tim Schmidt                                               */
/* Date: 11/09/2017                                                  */
/*                                                                   */
/* Movie.c: source file for basic movie manipulations                */
/*                                                                   */
/*********************************************************************/

#include <stdlib.h>
#include <assert.h>
#include "Movie.h"
#include "ImageList.h"
#include "Image.h"

/* Allocate the memory space for the movie and the memory space */
/* for the frame list. Return the pointer to the movie. */
MOVIE *CreateMovie(void)
{
    MOVIE *movie = (MOVIE *)malloc(sizeof(MOVIE));
    if (movie==NULL){
        return NULL;
    }

    movie->Frames = CreateImageList();
    if (movie->Frames==NULL){
        free(movie);
        return NULL;
    }
    return movie;
}

/* Release the memory space for the frame list. */
/* Release the memory space for the movie. */
void DeleteMovie(MOVIE *movie)
{
    assert(movie);
    assert(movie->Frames);
    DeleteImageList(movie->Frames);
    movie->Frames = NULL;

    free(movie);

}

/* Convert a YUV movie to a RGB movie */
void YUV2RGBMovie(MOVIE *movie)
{
    assert(movie);
    assert(movie->Frames);
 
    IENTRY *entry;
    unsigned char R, G, B;
    unsigned char Y,U,V; 
    int C, D, E;
    entry = movie->Frames->First;
    //Parse thru YUV and convert to RGB
    while(entry != NULL){
        assert(entry);
        for (int y = 0; y < ImageHeight(entry->RGBImage); y++){
            for (int x = 0; x < ImageWidth(entry->RGBImage); x++){
                Y = GetPixelY(entry->YUVImage,x,y);
                U = GetPixelU(entry->YUVImage,x,y);
                V = GetPixelV(entry->YUVImage,x,y);
                C = Y - 16;
                D = U - 128;
                E = V - 128;
                R = clip(( 298 * C + 409 * E + 128) >> 8);
                G = clip(( 298 * C - 100 * D - 208 * E + 128) >> 8);
                B = clip(( 298 * C + 516 * D + 128) >> 8);
                SetPixelR(entry->RGBImage,x,y,R);
                SetPixelG(entry->RGBImage,x,y,G);
                SetPixelB(entry->RGBImage,x,y,B);
            }
        }
        entry = entry->Next;
    }
    
}

/* Convert a RGB movie to a YUV movie */
void RGB2YUVMovie(MOVIE *movie)
{
    assert(movie);
    assert(movie->Frames);

    IENTRY *entry;
    unsigned char R, G, B;
    unsigned char Y,U,V; 
    YUVIMAGE *YUV;
    entry = movie->Frames->First;
    int height = ImageHeight(entry->RGBImage);
    int width = ImageWidth(entry->RGBImage);
    // Parse through RGB and convert to YUV
    while(entry != NULL){
        YUV = CreateYUVImage(width,height);
        entry->YUVImage = YUV;
        assert(entry);
        for (int y = 0; y < height; y++){
            for (int x = 0; x < width; x++){
                R = GetPixelR(entry->RGBImage,x,y);
                G = GetPixelG(entry->RGBImage,x,y);
                B = GetPixelB(entry->RGBImage,x,y);
                Y=clip((( 66*R+129*G+ 25*B+128)>>8)+ 16);
                U=clip(((-38*R- 74*G+112*B+128)>>8)+128);
                V=clip(((112*R- 94*G- 18*B+128)>>8)+128);
                SetPixelY(entry->YUVImage,x,y,Y);
                SetPixelU(entry->YUVImage,x,y,U);
                SetPixelV(entry->YUVImage,x,y,V);
            }
        }
        entry = entry->Next;
    }

}

// clip a value 0-255
int clip(int x){
    if (x>255){
        return 255;
    }
    else if (x<0){
        return 0;
    }
    else{
        return (unsigned char)x;
    }
}

int MovieLength(const MOVIE *movie)
{
    assert(movie);
    assert(movie->Frames);
    return(movie->Frames->length);
}

int MovieHeight(const MOVIE *movie)
{
    assert(movie);
    assert(movie->Frames);
    assert(movie->Frames->First->RGBImage);
    assert(movie->Frames->First->YUVImage);
    //Check for existing Image
    if (movie->Frames->First->RGBImage!=NULL){
        return movie->Frames->First->RGBImage->H;
    }
    else if (movie->Frames->First->YUVImage!=NULL){
        return movie->Frames->First->YUVImage->H;
    }    
    return 0;
}

int MovieWidth(const MOVIE *movie)
{
    assert(movie);
    assert(movie->Frames);
    assert(movie->Frames->First->RGBImage);
    assert(movie->Frames->First->YUVImage);
//Check for existing Image
    if (movie->Frames->First->RGBImage!=NULL){
        return movie->Frames->First->RGBImage->W;
    }
    else if (movie->Frames->First->YUVImage!=NULL){
        return movie->Frames->First->YUVImage->W;
    }  
    return 0;
}

/* EOF */
