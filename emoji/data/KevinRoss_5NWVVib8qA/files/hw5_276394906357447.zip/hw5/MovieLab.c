/*********************************************************************/
/* Homework Assignment 5, for EECS 22, Fall 2017                     */
/* Modified by Mihnea Chirila for EECS 22 Fall 2018                                                            */
/* Author: Tim Schmidt                                               */
/* Date: 11/09/2017                                                  */
/*                                                                   */
/* MovieLab.c: source file for the main function                     */
/*                                                                   */
/* Please use this template for your HW5.                            */
/*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "FileIO.h"
#include "DIPs.h"
#include "Movie.h"
#include "Constants.h"
#include "Image.h"
#include "MovieIO.h"
#include "IterativeFilter.h"
#include "stdbool.h"

int main(int argc, char *argv[])
{
    int x;
    char *inie = NULL, *outie= NULL, *temp= NULL, *minie = NULL;
    MOVIE *movie;
    IMAGE *image;
    float start, step, end;
    bool hue, reverse;
    int width, height, fNum;
    const char s[1] = "x"; // Deliminator 

    // Get command line arguments
    for (x = 1; x<argc; x++){
        // get input file
        if (strcmp(argv[x], "-i")==0){
            inie = argv[x+1];
            x++;    
        }
        // get output file
        else if (strcmp(argv[x], "-o")==0){
            outie = argv[x+1];    
            x++;    
        }
        // get start num
        else if (strcmp(argv[x], "-start=")==0){
            start = strtof(argv[x+1], NULL);
           
            x++;    
        }
        // get end num
        else if (strcmp(argv[x], "-end=")==0){
            end = strtof(argv[x+1], NULL);
            x++;    
            
        }
        // get step num
        else if (strcmp(argv[x], "-step=")==0){
            step = strtof(argv[x+1], NULL);
            x++;    
        }

        //check if hue flag is enabled
        else if (strcmp(argv[x], "-hue")==0){
            hue = true;
        }
        // get input movie file
        else if (strcmp(argv[x], "-m")==0){
            minie = argv[x+1];
            x++;    
        }
        // get number of frames
        else if (strcmp(argv[x], "-f")==0){
            fNum = atoi(argv[x+1]);
            x++;    
        }

        // get size
        else if (strcmp(argv[x], "-s")==0){
            // Use tokens with a delimeter of x
            temp = strtok(argv[x+1], s);
            width = atoi(temp);
            temp = strtok(NULL, s);
            height = atoi(temp);
            x++;    
        }
        // check if reverse flag is enabled
        else if (strcmp(argv[x], "-reverse")==0){
            reverse = true;
        }
    }
    // Output verification check
    if (outie == NULL){
        printf("No output file given!\n");
        return 1;
    }
    // Image selection
    if (inie != NULL){
        image = LoadImage(inie);
        assert(image);
        // run hue filter over steps
        if(hue){
            movie = doIterativeFilter(image, &HueRotate, start, end, step);
            printf("Hue Rotate done!\n");
        }
        else {
            printf("No filter given!\n");
            return 1;
        }
        SaveMovie(outie, movie);
        DeleteMovie(movie);
    }
    // Movie selection
    else if (minie != NULL){
        movie = LoadMovie(minie, fNum, width, height);
        assert(movie);
        // run reverse filter 
        if (reverse){
            ReverseImageList(movie->Frames);
            printf("Reversing done!\n");
        }
        else {
            printf("No filter given!\n");
            DeleteMovie(movie);
            return 1;
        }
        SaveMovie(outie, movie);
        DeleteMovie(movie);
    }
    // Input verification check
    else{
        printf("No input file given!\n");
        return 1;
    }
    return 0;
}

/* EOF */
